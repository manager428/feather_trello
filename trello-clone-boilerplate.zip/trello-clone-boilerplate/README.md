To spin up a local database, use the following command:

`docker run -p 27017:27017 --rm --name trello-clone-mongodb -v ~/path/to/data/data:/data/db mongo:latest`


