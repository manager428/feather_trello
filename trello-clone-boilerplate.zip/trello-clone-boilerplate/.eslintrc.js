module.exports = {
  root: true,
  parserOptions: {
    ecmaVersion: 11,
  },
  globals: {
    '_': false,
    moment: false,
  },
};
