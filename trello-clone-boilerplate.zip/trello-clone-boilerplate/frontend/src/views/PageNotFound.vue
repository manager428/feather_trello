<template>
  <div id="pageNotFound">
  </div>
</template>

<script>

export default {
  name: 'PageNotFound',
};
</script>
<style>
  #pageNotFound {
    background-image: url('https://img.freepik.com/premium-photo/3d-render-404-error-page-found-design-pastel-color-background_10876-742.jpg?size=626&ext=jpg');
    background-position: center center;
    background-repeat: no-repeat;
    background-size: cover;
    height: calc(100vh - 60px);
    width: 100%;
  }
</style>
