// We might add more validators in the future
// eslint-disable-next-line import/prefer-default-export
export const notEmptyRules = [(value) => !!value || 'Cannot be empty.'];
