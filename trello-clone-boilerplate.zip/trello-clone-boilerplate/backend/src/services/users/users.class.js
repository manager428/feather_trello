import { Service } from 'feathers-mongoose';

export class Users extends Service {

}
