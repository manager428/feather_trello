import { Service } from 'feathers-mongoose';

export class Lists extends Service {

}
