import { Service } from 'feathers-mongoose';

export class Cards extends Service {

}
